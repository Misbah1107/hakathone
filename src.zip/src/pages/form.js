import React, { useState } from "react"
import {useSelector,useDispatch} from 'react-redux'
import { Senddata } from "../store/Action"

function Form() {
    const state = useSelector(state => state)
    // console.log(state)
  
     const[name,setname]=useState("")
     const[phonenumber,setphonenumber]=useState("")
     const[email,setemail]=useState("")
     const[cnic,setcnic]=useState("")
     const[price,setprice]=useState("")
     const[size,setsize]=useState("")
     const[stay,setstay]=useState("")
     const[person,setperson]=useState("")
     const[addreas,setaddreas]=useState("")
     const[type,settype]=useState("")
     
     function send() {
       const data={
            name,
            phonenumber,
            email,
            cnic,
            price,
            size,
            stay,
            person,
            addreas,
            type,
         }
         state.user.uid?Senddata(state.user.uid,data):alert("first login")
              
     }
    return (
        <div className="rounded p-1" id="main-div">
            {/* <h3 className="contact-us"><a href="#" className="Contact-heading">Form</a> </h3> */}
            {/* <form action> */}
                {/* <input id="firstname" className="conatc-inputs" type="text" placeholder="First Name" /> */}
                
               <div >
                   {/* <span className="input-font">Name:	&nbsp;	&nbsp;	&nbsp;	&nbsp; 	&nbsp; 	&nbsp;	&nbsp;</span> */}
                   <h5 className="input-font">Name</h5>
                <input id="lasttname" className="conatc-inputs" onChange={(e) => { setname(e.target.value) }} type="text" placeholder="name" />
               </div>
               <div>
               <h5 className="input-font">Phone number</h5>
                <input id="Phonenumber" className="conatc-inputs" onChange={(e) => { setphonenumber(e.target.value) }} type="text" placeholder="Phone number" />
               </div>
               <div>
               <h5 className="input-font">E mail</h5>
                <input id="Email" className="conatc-inputs" onChange={(e) => { setemail(e.target.value) }} type="email" placeholder="E-Mail" />
               </div>
               <div>
               <h5 className="input-font">CNIC</h5>
                <input id="Email" className="conatc-inputs"  onChange={(e) => { setcnic(e.target.value) }} type="text" placeholder="CNIC" />
               </div>
               <div>
               <h5 className="input-font">Price</h5>
                <input id="Email" className="conatc-inputs"  onChange={(e) => { setprice(e.target.value) }} type="text" placeholder="price" />
               </div>
               <div>
               <h5 className="input-font">Room size</h5>
                <input id="Email" className="conatc-inputs"  onChange={(e) => { setsize(e.target.value) }} type="text" placeholder="Room size" />
               </div>
               <div>
               <h5 className="input-font">Number of stay</h5>
                <input id="Email" className="conatc-inputs"  onChange={(e) => { setstay(e.target.value) }} type="text" placeholder="Number of days stay" />
               </div>
               <div>
               <h5 className="input-font">Number of peson</h5>
                <input id="Email" className="conatc-inputs" type="text"  onChange={(e) => { setperson(e.target.value) }} placeholder="Number of person" />
               </div>
               <div>
               <h5 className="input-font">Address</h5>
                <input id="Email" className="conatc-inputs" type="text"  onChange={(e) => { setaddreas(e.target.value) }} placeholder="Address" />
               </div>

                <div className="room-typ">
                <h5 className="input-font">room type</h5>

                <select  name="type" id="type" onChange={(e) => { settype(e.target.value) }} class="conatc-inputs"><option value="all">all</option><option value="single">single</option><option value="double">double</option><option value="family">family</option><option value="presidential">presidential</option></select>
                </div>
            {/* </form> */}
            <div className="btn-div">
                <button type="submit" onClick={send} className="Submit-btn rounded my-2 my-sm-0 px-3 py-2">Submit</button>
            </div>
        </div>
    )
}

export default Form