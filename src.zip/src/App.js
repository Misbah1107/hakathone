import React from "react";
import "./App.css";
import AdminPanel from './AdminPanel.js/AdminPanel'

import Home from "./pages/Home";
import Rooms from "./pages/Rooms";
import SingleRoom from "./pages/SingleRoom";
import Error from "./pages/Error";
import Form from "./pages/form";
import Navbar from "./components/Navbar";

import { Switch, Route } from "react-router-dom";

import { Provider } from 'react-redux';
import store from "./store/store";

function App() {
  
  return (
    <>
    <Provider store={store}>

      <Navbar />
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/form" component={Form} />
        <Route exact path="/rooms/" component={Rooms} />
        <Route exact path="/rooms/:slug" component={SingleRoom} />
        <Route exact path="/adminpanel" component={<AdminPanel/>} />  
        <Route component={Error} />
      </Switch>

    </Provider>
    </>
  );
}

export default App;
