import React from 'react'
import './Addmin.css'
function AdminPanel() {
    return (
        <div>
            <div className="container">
        <div className="navigation">
          <ul>
            <li>
              <a href="#">
                <span className="icon" />
                <span className="title">
                  <h2>Brand Name</h2>
                </span>
              </a>
            </li>
            <li>
              <a href="#">
                <span className="icon"><i className="fas fa-home" /></span>
                <span className="title">Dashboard</span>
              </a>
            </li>
            <li>
              <a href="#">
                <span className="icon"><i className="fas fa-users" /></span>
                <span className="title">Customers</span>
              </a>
            </li>
            <li>
              <a href="#">
                <span className="icon"><i className="fas fa-comments" /></span>
                <span className="title">Message</span>
              </a>
            </li>
            <li>
              <a href="#">
                <span className="icon"><i className="fas fa-question-circle" /></span>
                <span className="title">Help</span>
              </a>
            </li>
            <li>
              <a href="#">
                <span className="icon"><i className="fas fa-cog" /></span>
                <span className="title">Settings</span>
              </a>
            </li>
            <li>
              <a href="#">
                <span className="icon"><i className="fas fa-lock-open" /></span>
                <span className="title">Password</span>
              </a>
            </li>
            <li>
              <a href="#">
                <span className="icon"><i className="fas fa-sign-out-alt" /></span>
                <span className="title">Sign Out</span>
              </a>
            </li>
          </ul>
        </div>
        <div className="main">
          <div className="topbar">
            <div className="toggle" onclick="toggleMenu()" />
            <div className="search">
              <label>
                <input type="text" placeholder="search here" />
                <i className="fas fa-search" />
              </label>
            </div>
            <div className="user">
              <img src="imag/wild-vibes-1RnPg7tET_s-unsplash.jpg" alt="" />
            </div>
          </div>
          <div className="cardBox">
            <div className="card">
              <div>
                <div className="numbers">1,042</div>
                <div className="cardName">Daily Views</div>
              </div>
              <div className="iconBox">
                <i className="fas fa-eye" />
              </div>
            </div>
            <div className="card">
              <div>
                <div className="numbers">80</div>
                <div className="cardName">Sales</div>
              </div>
              <div className="iconBox">
                <i className="fas fa-shopping-cart" />
              </div>
            </div>
            <div className="card">
              <div>
                <div className="numbers">208</div>
                <div className="cardName">Comments</div>
              </div>
              <div className="iconBox">
                <i className="far fa-comments" />
              </div>
            </div>
            <div className="card">
              <div>
                <div className="numbers">RS. 6,042</div>
                <div className="cardName">Earning</div>
              </div>
              <div className="iconBox">
                <i className="fas fa-dollar-sign" />
              </div>
            </div>
          </div>
          <div className="details">
            <div className="recentOrders">
              <div className="cardHeader">
                <h2>Recent Orders</h2>
                <a href="#" className="btn">View All</a>
              </div>
              <table>
                <thead>
                  <tr>
                    <td><h4>Name</h4></td>
                    <td><h4>Price</h4></td>
                    <td><h4>Payment</h4></td>
                    <td><h4>Status</h4></td>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Star Refrigerator</td>
                    <td>Rs. 1200</td>
                    <td>paid</td>
                    <td><span className="status delivered">Delivered</span></td>
                  </tr>
                  <tr>
                    <td>Star Refrigerator</td>
                    <td>Rs. 1200</td>
                    <td>Due</td>
                    <td><span className="status pending">Pending</span></td>
                  </tr>
                  <tr>
                    <td>Star Refrigerator</td>
                    <td>Rs. 1200</td>
                    <td>paid</td>
                    <td><span className="status return">Return</span></td>
                  </tr>
                  <tr>
                    <td>Star Refrigerator</td>
                    <td>Rs. 1200</td>
                    <td>Due</td>
                    <td><span className="status inProgress">In Progress</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="recentCustomers">
              <div className="cardHeader">
                <h2>Recent Customers</h2>
                <div>
                  <ul id="list">
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
        </div>
    )
}

export default AdminPanel
