import firebase  from "firebase";
import 'firebase/auth'
import 'firebase/database'
import 'firebase/auth'

const firebaseConfig = {
  apiKey: "AIzaSyAcXPx655mwt_VbJq5kvvFYIEwD-26Bd8A",
  authDomain: "hackathone-32904.firebaseapp.com",
  projectId: "hackathone-32904",
  storageBucket: "hackathone-32904.appspot.com",
  messagingSenderId: "600801502832",
  appId: "1:600801502832:web:e37c5e8b23acb46d5636b5"
};
// Initialize Firebase

let Firebase= firebase.initializeApp(firebaseConfig);
let provider = new firebase.auth.FacebookAuthProvider();
let googleprovider = new firebase.auth.GoogleAuthProvider();


export{
  Firebase,
  provider,
  googleprovider
}