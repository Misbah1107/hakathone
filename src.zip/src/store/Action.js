import React from 'react'
import { Firebase, provider, googleprovider } from "../firebase/firebase";


const Googlelogin = () => {
    // const auth = getAuth();
    return (dispatch) => {
        return new Promise((resolve, reject) => {
            Firebase.auth().signInWithPopup(googleprovider)
                .then((result) => {
                    const user = result.user;
                    // console.log(result.user)
                    dispatch({ type: "GETUSER", user: result.user })
                    resolve(result.user.uid)

                }).catch((error) => {
                    console.log(error)
                });
        })
    }
}

const Senddata=(id,data)=>{
    Firebase.database().ref('users').child(id).set(data)
    alert("form submited")    
}
export {
    Googlelogin,
    Senddata,
}