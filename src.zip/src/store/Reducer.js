const INITAIL_STATE = {
    email: "example@gail.com",
    user:''
}

export default (state = INITAIL_STATE, action) => {

    switch (action.type) {
        case "GETUSER":
          return ({
            ...state,
          user:action.user,
        })
        default:
          return state
      }

}