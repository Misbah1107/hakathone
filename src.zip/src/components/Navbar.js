import React, { Component } from "react";
import { Link, useParams } from "react-router-dom";
import { FaAlignRight } from "react-icons/fa";
import logo from "../images/logo.svg";
import { useDispatch, useSelector } from 'react-redux'
import { Googlelogin } from "../store/Action"
// export default class Navbar extends Component {


// state = {
//   isOpen: false
// };
// handleToggle = () => {
//   this.setState({ isOpen: !this.state.isOpen });
// };
// handleSubmit = () => {
//   dispatch = useDispatch()
//   dispatch(Action.data)
// }


// render() {
function Navbar() {
  const state = useSelector(state => state)
  console.log(state.user)

  

  const dispatch = useDispatch()
  function login() {
    dispatch(Googlelogin())
    .then((UID) => {
    //  console.log(UID)
    }).catch(() => {
    })

  }
  return (
    <nav className="navbar">
      <div className="nav-center">
        <div className="nav-header">
          <Link to="/">
            <img src={logo} alt="Beach Resort" />
          </Link>
          <button
            type="button"
            className="nav-btn"
          // onClick={this.handleToggle}
          >
            <FaAlignRight className="nav-icon" />
          </button>
        </div>
        <ul
          className={"nav-links"}
        >
          <li>
            <Link to="/">Home</Link>
          </li>
          <li>
            <Link to="/rooms">Rooms</Link>
          </li>
        </ul>
        {state.user ? <p className="login-name">{state.user.displayName }</p> : <button className="btn-primary" onClick={login}>Google login</button>}
        {/* <button onClick={Signout} >Signout</button> */}

      </div>
    </nav>
  );
  //   }
  // }

}
export default Navbar